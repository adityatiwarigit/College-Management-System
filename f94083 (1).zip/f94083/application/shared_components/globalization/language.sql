prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 94083
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>31347139869382414289
,p_default_application_id=>94083
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTADITYA'
);
null;
wwv_flow_imp.component_end;
end;
/
