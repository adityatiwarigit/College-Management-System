prompt --application/shared_components/user_interface/templates/report/gallary
begin
--   Manifest
--     ROW TEMPLATE: GALLARY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>31347139869382414289
,p_default_application_id=>94083
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTADITYA'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(39336539683187302798)
,p_row_template_name=>'GALLARY'
,p_internal_name=>'GALLARY'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function magnify(imgID, zoom) {',
'        var img, glass, w, h, bw;',
'        img = document.getElementById(imgID);',
'',
'        /*create magnifier glass:*/',
'        glass = document.createElement("DIV");',
'        glass.setAttribute("class", "img-magnifier-glass");',
'',
'        /*insert magnifier glass:*/',
'        img.parentElement.insertBefore(glass, img);',
'',
'        /*set background properties for the magnifier glass:*/',
'        glass.style.backgroundImage = "url(''" + img.src + "'')";',
'        glass.style.backgroundRepeat = "no-repeat";',
'        glass.style.backgroundSize = (img.width * zoom) + "px " + (img.height * zoom) + "px";',
'        bw = 3;',
'        w = glass.offsetWidth / 2;',
'        h = glass.offsetHeight / 2;',
'',
'        /*execute a function when someone moves the magnifier glass over the image:*/',
'        glass.addEventListener("mousemove", moveMagnifier);',
'        img.addEventListener("mousemove", moveMagnifier);',
'',
'        /*and also for touch screens:*/',
'        glass.addEventListener("touchmove", moveMagnifier);',
'        img.addEventListener("touchmove", moveMagnifier);',
'        function moveMagnifier(e) {',
'          var pos, x, y;',
'          /*prevent any other actions that may occur when moving over the image*/',
'          e.preventDefault();',
'          /*get the cursor''s x and y positions:*/',
'          pos = getCursorPos(e);',
'          x = pos.x;',
'          y = pos.y;',
'          /*prevent the magnifier glass from being positioned outside the image:*/',
'          if (x > img.width - (w / zoom)) {x = img.width - (w / zoom);}',
'          if (x < w / zoom) {x = w / zoom;}',
'          if (y > img.height - (h / zoom)) {y = img.height - (h / zoom);}',
'          if (y < h / zoom) {y = h / zoom;}',
'          /*set the position of the magnifier glass:*/',
'          glass.style.left = (x - w) + "px";',
'          glass.style.top = (y - h) + "px";',
'          /*display what the magnifier glass "sees":*/',
'          glass.style.backgroundPosition = "-" + ((x * zoom) - w + bw) + "px -" + ((y * zoom) - h + bw) + "px";',
'        }',
'',
'        function getCursorPos(e) {',
'          var a, x = 0, y = 0;',
'          e = e || window.event;',
'          /*get the x and y positions of the image:*/',
'          a = img.getBoundingClientRect();',
'          /*calculate the cursor''s x and y coordinates, relative to the image:*/',
'          x = e.pageX - a.left;',
'          y = e.pageY - a.top;',
'          /*consider any page scrolling:*/',
'          x = x - window.pageXOffset;',
'          y = y - window.pageYOffset;',
'          return {x : x, y : y};',
'        }',
'      }',
'',
'',
'      $("img").click(function(){',
'          const imgClone = $(this).parent();',
'          $(".gallary-bg").addClass("gallary-bg-block")',
'          $(".gallary-bg").append(imgClone.clone());',
'          $(".gallary-bg .img-item img").addClass("animated fadeIn");',
'          $(".gallary-bg").removeClass("animated fadeOut");',
'          $(''.gallary-bg .img-item img'').attr(''id'', ''myimage'');',
'          ',
'          magnify("myimage", 2);',
'          ',
'        });',
'',
'        $(".gallary-bg").click(function() {                 ',
'          $(this).addClass("animated fadeOut");',
'          $(this).children().children().addClass("fadeLeft");          ',
'          $(this).children().remove();',
'          var rmBg= $(this);',
'          setTimeout(() => {',
'            rmBg.removeClass("gallary-bg-block");',
'          }, 400);',
' });',
'',
'',
'    '))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'body{',
'  font-family: "Montserrat", sans-serif;',
'}',
'',
'.main-wrapper {',
'  padding: 50px 0;',
'}',
'',
'img {',
'  cursor: pointer;',
'}',
'',
'.img-wrapper {',
'  margin: 10px 0;',
'  transition: left 1s linear;',
'}',
'',
'.img-wrapper .img-item{',
'  overflow: hidden;',
'}',
'',
'.img-wrapper .img-item img{',
'  transition: all ease-in 0.1s;',
'}',
'',
'.img-wrapper .img-item img:hover{',
'  transform: scale(1.1);',
'}',
'',
'.gallary-bg {',
'  position: fixed;',
'  top: 0;',
'  bottom: 0;',
'  left: 0;',
'  right: 0;',
'  background-color: #000000c7;',
'  display: none;',
'  cursor: pointer;',
'}',
'',
'.gallary-bg-block {',
'  display: block;',
'}',
'',
'.gallary-bg-block .img-item {',
'  position: absolute;',
'  left: 50%;',
'  top: 50%;',
'  transform: translate(-50%, -50%);',
'}',
'',
'.gallary-bg .img-item > img {',
'  transition: all ease-in 0.5s;',
'  transform: scale(0);',
'}',
'',
'.gallary-bg-block .img-item > img {',
'  transform: scale(1);',
'  padding: 5px;',
'  border: 2px solid #ffffff;',
'  border-radius: 2px;',
'}',
'',
'.img-magnifier-glass {',
'  position: absolute;',
'  border: 3px solid #000;',
'  border-radius: 50%;',
'  cursor: none;',
'  /*Set the size of the magnifier glass:*/',
'  width: 200px;',
'  height: 200px;',
'  z-index: 999999;',
'}',
'',
'.img-magnifier-glass:after {',
'    content: url(https://cdn3.iconfinder.com/data/icons/virtual-notebook/16/button_shape_line-512.png);',
'    height: 50px;',
'    width: 46px;',
'    position: absolute;',
'    transform: scale(0.3) rotate(61deg);',
'    right: -30px;',
'    bottom: 22px;',
'}'))
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
' <div class="img-wrapper">',
'              <div class="img-item text-center">',
'                <img src="https://images.pexels.com/photos/34199/pexels-photo.jpg?auto=compress&cs=tinysrgb&h=750&w=1260" alt="" class="img-fluid">',
'              </div>',
'            </div>'))
,p_row_template_condition1=>':CARD_LINK is not null'
,p_row_template2=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            <div class="img-wrapper">',
'              <div class="img-item text-center">',
'                <img src="https://images.pexels.com/photos/693267/pexels-photo-693267.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260" alt="" class="img-fluid">',
'              </div>',
'            </div>             '))
,p_row_template3=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            <div class="img-wrapper">',
'              <div class="img-item text-center">',
'                <img src="https://images.pexels.com/photos/1366929/pexels-photo-1366929.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260" alt="" class="img-fluid">',
'              </div>',
'            </div>',
''))
,p_row_template4=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            <div class="img-wrapper">',
'              <div class="img-item text-center">',
'                <img src="https://images.pexels.com/photos/34199/pexels-photo.jpg?auto=compress&cs=tinysrgb&h=750&w=1260" alt="" class="img-fluid">',
'              </div>',
'            </div>',
''))
,p_row_template_before_rows=>'<ul class="t-Cards #COMPONENT_CSS_CLASSES#" #REPORT_ATTRIBUTES# id="#REGION_STATIC_ID#_cards" data-region-id="#REGION_STATIC_ID#">'
,p_row_template_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'</ul>',
'<table class="t-Report-pagination" role="presentation">#PAGINATION#</table>'))
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'NOT_CONDITIONAL'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'NOT_CONDITIONAL'
,p_pagination_template=>'<span class="t-Report-paginationText">#TEXT#</span>'
,p_next_page_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--next">',
'  #PAGINATION_NEXT#<span class="a-Icon icon-right-arrow" aria-hidden="true"></span>',
'</a>'))
,p_previous_page_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--prev">',
'  <span class="a-Icon icon-left-arrow" aria-hidden="true"></span>#PAGINATION_PREVIOUS#',
'</a>'))
,p_next_set_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--next">',
'  #PAGINATION_NEXT_SET#<span class="a-Icon icon-right-arrow" aria-hidden="true"></span>',
'</a>'))
,p_previous_set_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--prev">',
'  <span class="a-Icon icon-left-arrow" aria-hidden="true"></span>#PAGINATION_PREVIOUS_SET#',
'</a>'))
,p_theme_id=>42
,p_theme_class_id=>7
,p_preset_template_options=>'t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
);
wwv_flow_imp.component_end;
end;
/
