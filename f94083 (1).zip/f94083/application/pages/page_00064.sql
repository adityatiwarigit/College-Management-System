prompt --application/pages/page_00064
begin
--   Manifest
--     PAGE: 00064
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>31347139869382414289
,p_default_application_id=>94083
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTADITYA'
);
wwv_flow_imp_page.create_page(
 p_id=>64
,p_name=>'QUERY REPORT'
,p_alias=>'QUERY-REPORT'
,p_step_title=>'QUERY REPORT'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'AT2695275@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220821021015'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41321582998667187183)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38119421488543883165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38118811960332883117)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38119483515043883192)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(41321583576787187183)
,p_name=>'QUERY REPORT'
,p_template=>wwv_flow_imp.id(38119409098980883160)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'SELECT * FROM CMS_QUERY_FORUM WHERE ANSWER IS NOT NULL AND QUERY IS NOT NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(38119446955262883175)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41321583977440187185)
,p_query_column_id=>1
,p_column_alias=>'ENROLLMENT_NO'
,p_column_display_sequence=>1
,p_column_heading=>'Enrollment No'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41321584381088187185)
,p_query_column_id=>2
,p_column_alias=>'QUERY'
,p_column_display_sequence=>2
,p_column_heading=>'Query'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41321584788989187186)
,p_query_column_id=>3
,p_column_alias=>'ANSWER'
,p_column_display_sequence=>3
,p_column_heading=>'Answer'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41321585151928187186)
,p_query_column_id=>4
,p_column_alias=>'SUBJECT'
,p_column_display_sequence=>4
,p_column_heading=>'Subject'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
