prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>31347139869382414289
,p_default_application_id=>94083
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTADITYA'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'SERVICES'
,p_alias=>'SERVICES'
,p_step_title=>'SERVICES'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@import url(https://fonts.googleapis.com/css?family=Roboto:300,400,600);',
'.snip1336 {',
'  font-family: ''Roboto'', Arial, sans-serif;',
'  position: relative;',
'  overflow: hidden;',
'  margin: 10px;',
'  min-width: 230px;',
'  max-width: 315px;',
'  width: 100%;',
'  color: #ffffff;',
'  text-align: left;',
'  line-height: 1.4em;',
'  background-color: #141414;',
'}',
'.snip1336 * {',
'  -webkit-box-sizing: border-box;',
'  box-sizing: border-box;',
'  -webkit-transition: all 0.25s ease;',
'  transition: all 0.25s ease;',
'}',
'.snip1336 img {',
'  max-width: 100%;',
'  vertical-align: top;',
'  opacity: 0.85;',
'}',
'.snip1336 figcaption {',
'  width: 100%;',
'  background-color: #141414;',
'  padding: 25px;',
'  position: relative;',
'}',
'.snip1336 figcaption:before {',
'  position: absolute;',
'  content: '''';',
'  bottom: 100%;',
'  left: 0;',
'  width: 0;',
'  height: 0;',
'  border-style: solid;',
'  border-width: 55px 0 0 400px;',
'  border-color: transparent transparent transparent #141414;',
'}',
'.snip1336 figcaption a {',
'  padding: 5px;',
'  border: 1px solid #ffffff;',
'  color: #ffffff;',
'  font-size: 0.7em;',
'  text-transform: uppercase;',
'  margin: 10px 0;',
'  display: inline-block;',
'  opacity: 0.65;',
'  width: 47%;',
'  text-align: center;',
'  text-decoration: none;',
'  font-weight: 600;',
'  letter-spacing: 1px;',
'}',
'.snip1336 figcaption a:hover {',
'  opacity: 1;',
'}',
'.snip1336 .profile {',
'  border-radius: 50%;',
'  position: absolute;',
'  bottom: 100%;',
'  left: 25px;',
'  z-index: 1;',
'  max-width: 90px;',
'  opacity: 1;',
'  box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);',
'}',
'.snip1336 .follow {',
'  margin-right: 4%;',
'  border-color: #2980b9;',
'  color: #2980b9;',
'}',
'.snip1336 h2 {',
'  margin: 0 0 5px;',
'  font-weight: 300;',
'}',
'.snip1336 h2 span {',
'  display: block;',
'  font-size: 0.5em;',
'  color: #2980b9;',
'}',
'.snip1336 p {',
'  margin: 0 0 10px;',
'  font-size: 0.8em;',
'  letter-spacing: 1px;',
'  opacity: 0.8;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'AT2695275@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220813052134'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39252408143164123431)
,p_name=>'SERVICES'
,p_template=>wwv_flow_imp.id(38119409098980883160)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'CMS_SERVICES'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(38447545653463508413)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39252408275968123432)
,p_query_column_id=>1
,p_column_alias=>'SERVICE_NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Service Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39252408364378123433)
,p_query_column_id=>2
,p_column_alias=>'SERVICE_DISCRIPTION'
,p_column_display_sequence=>20
,p_column_heading=>'Service Discription'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39252408443878123434)
,p_query_column_id=>3
,p_column_alias=>'PHOTO_GRAPH'
,p_column_display_sequence=>30
,p_column_heading=>'Photo Graph'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39252408569457123435)
,p_query_column_id=>4
,p_column_alias=>'PROFILE_PHOTO'
,p_column_display_sequence=>40
,p_column_heading=>'Profile Photo'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39272626003383695005)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38119421488543883165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38118811960332883117)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38119483515043883192)
);
wwv_flow_imp.component_end;
end;
/
