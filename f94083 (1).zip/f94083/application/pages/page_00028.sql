prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>31347139869382414289
,p_default_application_id=>94083
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTADITYA'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>'FACULTY DASHBOARD'
,p_alias=>'FACULTY-DASHBOARD'
,p_step_title=>'FACULTY DASHBOARD'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#test6{',
'background: url(#APP_FILES#FACULTY.webp);//add your image refrence url',
'width: 100%;',
'height: 600px;',
'background-size: cover',
'} '))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'AT2695275@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220821024347'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40790959332680696551)
,p_plug_name=>'Breadcrumb'
,p_region_name=>'test6'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38119421488543883165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38118811960332883117)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38119483515043883192)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp.component_end;
end;
/
